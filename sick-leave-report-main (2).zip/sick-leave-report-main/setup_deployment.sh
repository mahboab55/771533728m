#!/bin/bash

# هذا النص البرمجي يقوم بإعداد بيئة النشر الدائم للتطبيق

# إنشاء مجلد للنشر
mkdir -p /home/ubuntu/deployment

# نسخ ملفات المشروع إلى مجلد النشر
cp -r /home/ubuntu/flask_project/* /home/ubuntu/deployment/

# إنشاء المجلدات اللازمة
mkdir -p /home/ubuntu/deployment/static/uploads
mkdir -p /home/ubuntu/deployment/static/downloads

# نسخ ملف العرض التقديمي الأصلي إلى مجلد التحميل
cp /home/ubuntu/upload/inputt.pptx /home/ubuntu/deployment/static/uploads/

# تثبيت المتطلبات
pip3 install -r /home/ubuntu/deployment/requirements.txt

# إعداد التطبيق للنشر
cd /home/ubuntu/deployment
