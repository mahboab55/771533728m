#!/bin/bash

# هذا النص البرمجي يقوم بتكوين خادم الويب والنطاق للنشر الدائم

# تكوين خادم الويب
echo "تكوين خادم الويب للنشر الدائم..."

# إنشاء مجلد للنشر الدائم
mkdir -p /home/ubuntu/permanent_deployment

# نسخ جميع ملفات المشروع إلى مجلد النشر الدائم
cp -r /home/ubuntu/flask_project/* /home/ubuntu/permanent_deployment/

# إنشاء ملف wsgi.py للنشر
cat > /home/ubuntu/permanent_deployment/wsgi.py << EOL
from app_for_deployment import app

if __name__ == "__main__":
    app.run()
EOL

echo "تم تكوين خادم الويب بنجاح!"
