import os
import logging
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from werkzeug.utils import secure_filename
from datetime import datetime
from utils.code_generator import generate_random_code
from utils.babel_config import configure_babel
from flask_cors import CORS

# إعداد التسجيل
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# استخدام متغيرات البيئة للمجلدات إذا كانت متوفرة
UPLOAD_FOLDER = os.environ.get('UPLOAD_FOLDER', '/tmp/uploads')
DOWNLOAD_FOLDER = os.environ.get('DOWNLOAD_FOLDER', '/tmp/downloads')
ALLOWED_EXTENSIONS = {'pptx'}
ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
# تمكين CORS لجميع المسارات والطرق
CORS(app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # حد أقصى 16 ميجابايت
app.secret_key = 'seha_sick_leave_report_secret_key'

# تكوين دعم اللغة العربية
configure_babel(app)

# التأكد من وجود المجلدات
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# التحقق من امتدادات الملفات المسموح بها
def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/form')
def form():
    return render_template('form.html')

@app.route('/submit', methods=['GET', 'POST'])
def submit_form():
    if request.method == 'POST':
        app.logger.debug(f"تم استلام طلب POST على المسار /submit")
        app.logger.debug(f"نماذج الطلب: {request.form}")
        app.logger.debug(f"ملفات الطلب: {request.files}")
        
        # التحقق من وجود ملف العرض التقديمي
        if 'inputt' not in request.files:
            app.logger.error("لم يتم تحديد ملف العرض التقديمي")
            flash('لم يتم تحديد ملف العرض التقديمي')
            return redirect(request.url)
        
        pptx_file = request.files['inputt']
        
        # التحقق من اختيار ملف
        if pptx_file.filename == '':
            app.logger.error("لم يتم اختيار ملف")
            flash('لم يتم اختيار ملف')
            return redirect(request.url)
        
        # التحقق من صحة امتداد الملف
        if not allowed_file(pptx_file.filename, ALLOWED_EXTENSIONS):
            app.logger.error(f"امتداد الملف غير مسموح به: {pptx_file.filename}")
            flash('امتداد الملف غير مسموح به. يرجى اختيار ملف بامتداد .pptx')
            return redirect(request.url)
        
        # إعادة إنشاء المجلدات للتأكد من وجودها
        os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
        
        # حفظ ملف العرض التقديمي
        pptx_filename = secure_filename(pptx_file.filename)
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        pptx_filename ="sickleaves"
        pptx_path = os.path.join(app.config['UPLOAD_FOLDER'], pptx_filename)
        app.logger.debug(f"مسار حفظ ملف العرض التقديمي: {pptx_path}")
        
        try:
            pptx_file.save(pptx_path)
            app.logger.debug(f"تم حفظ ملف العرض التقديمي بنجاح في: {pptx_path}")
        except Exception as e:
            app.logger.error(f"خطأ في حفظ ملف العرض التقديمي: {str(e)}")
            flash(f'حدث خطأ أثناء حفظ الملف: {str(e)}')
            return redirect(request.url)
        
        # معالجة الصورة إذا تم تحميلها
        image_path = None
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file.filename != '' and allowed_file(image_file.filename, ALLOWED_IMAGE_EXTENSIONS):
                image_filename = secure_filename(image_file.filename)
                image_filename = f"{timestamp}_{image_filename}"
                image_path = os.path.join(app.config['UPLOAD_FOLDER'], image_filename)
                app.logger.debug(f"مسار حفظ الصورة: {image_path}")
                
                try:
                    image_file.save(image_path)
                    app.logger.debug(f"تم حفظ الصورة بنجاح في: {image_path}")
                except Exception as e:
                    app.logger.error(f"خطأ في حفظ الصورة: {str(e)}")
                    flash(f'حدث خطأ أثناء حفظ الصورة: {str(e)}')
                    # نستمر حتى لو فشل حفظ الصورة
        
        # جمع البيانات من النموذج
        form_data = {
            'random_code': request.form.get('random_code', generate_random_code()),
            'name': request.form.get('name', ''),
            'name_en': request.form.get('name_en', ''),
            'id_number': request.form.get('id_number', ''),
            'employer': request.form.get('employer', ''),
            'medical_file_number': request.form.get('medical_file_number', ''),
            'admission_date': request.form.get('admission_date', ''),
            'admission_date_en': request.form.get('admission_date_en', ''),
            'discharge_date': request.form.get('discharge_date', ''),
            'discharge_date_en': request.form.get('discharge_date_en', ''),
            'issue_date': request.form.get('issue_date', ''),
            'time_date': request.form.get('time_date', ''),
            'hospital_name': request.form.get('hospital_name', ''),
            'hospital_name_en': request.form.get('hospital_name_en', ''),
            'physician_name': request.form.get('physician_name', ''),
            'physician_name_en': request.form.get('physician_name_en', ''),
            'physician_title': request.form.get('physician_title', ''),
            'physician_title_en': request.form.get('physician_title_en', ''),
            'license_number': request.form.get('license_number', ''),
            'image_path': image_path
        }
        
        app.logger.debug(f"بيانات النموذج: {form_data}")
        
        # معالجة ملف العرض التقديمي
        try:
            from utils.pptx_processor import process_pptx
            output_filename = f"output_{timestamp}.pptx"
            output_path = os.path.join(app.config['DOWNLOAD_FOLDER'], output_filename)
            app.logger.debug(f"مسار ملف الإخراج: {output_path}")
            
            # إنشاء قاموس البيانات بالتنسيق المطلوب لمعالجة ملف العرض التقديمي
            placeholders = {
                "الرمز": form_data['random_code'],
                "تاريخ_دخول": form_data['admission_date'],
                "تاريخ_خروج": form_data['discharge_date'],
                "تاريخ_اصدار": form_data['issue_date'],
                "الاسم": form_data['name'],
                "هويهه": form_data['id_number'],
                "جهة_عمل": form_data['employer'],
                "طبيب_معالج": form_data['physician_name'],
                "مسما": form_data['physician_title'],
                "num": form_data['medical_file_number'],
                "dat_in": form_data['admission_date_en'],
                "dat_out": form_data['discharge_date_en'],
                "name_en": form_data['name_en'],
                "name_doc": form_data['physician_name_en'],
                "postii": form_data['physician_title_en'],
                "مستشفى_اسم": form_data['hospital_name'],
                "hospital_name": form_data['hospital_name_en'],
                "ترخيصص": form_data['license_number'],
                "time_date": form_data['time_date']
            }
            
            app.logger.debug(f"قاموس البيانات للاستبدال: {placeholders}")
            
            # استخدام ملف القالب من متغير البيئة إذا كان متوفرًا
            template_path = os.environ.get('TEMPLATE_PATH')
            if template_path and os.path.exists(template_path):
                app.logger.debug(f"استخدام ملف القالب من متغير البيئة: {template_path}")
                pptx_path = template_path
            
            # معالجة ملف العرض التقديمي
            process_pptx(pptx_path, output_path, placeholders, image_path)
            app.logger.debug(f"تمت معالجة ملف العرض التقديمي بنجاح وحفظه في: {output_path}")
            
            # التحقق من وجود ملف الإخراج
            if os.path.exists(output_path):
                app.logger.debug(f"ملف الإخراج موجود: {output_path}")
            else:
                app.logger.error(f"ملف الإخراج غير موجود بعد الحفظ: {output_path}")
            
            # إرجاع صفحة النتائج
            return render_template('result.html', data=form_data, output_file=output_filename)
            
        except Exception as e:
            app.logger.error(f"خطأ في معالجة ملف العرض التقديمي: {str(e)}")
            flash(f'حدث خطأ أثناء معالجة الملف: {str(e)}')
            return render_template('result.html', error=str(e))
    
    # إضافة معالجة لطلبات GET
    elif request.method == 'GET':
        app.logger.debug("تم استلام طلب GET على المسار /submit")
        return redirect(url_for('form'))
    
    return redirect(url_for('form'))

@app.route('/download/<filename>')
def download_file(filename):
    app.logger.debug(f"طلب تنزيل الملف: {filename}")
    app.logger.debug(f"مسار مجلد التنزيل: {app.config['DOWNLOAD_FOLDER']}")
    
    # التحقق من وجود الملف
    file_path = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
    if os.path.exists(file_path):
        app.logger.debug(f"الملف موجود: {file_path}")
    else:
        app.logger.error(f"الملف غير موجود: {file_path}")
    
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
