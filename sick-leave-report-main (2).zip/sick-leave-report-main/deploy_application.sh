#!/bin/bash

# هذا النص البرمجي يقوم بنشر التطبيق بشكل دائم

# إنشاء مجلد للنشر النهائي
mkdir -p /home/ubuntu/final_deployment
mkdir -p /home/ubuntu/final_deployment/static/uploads
mkdir -p /home/ubuntu/final_deployment/static/downloads

# نسخ جميع ملفات المشروع إلى مجلد النشر النهائي
cp -r /home/ubuntu/flask_project/templates /home/ubuntu/final_deployment/
cp -r /home/ubuntu/flask_project/static/css /home/ubuntu/final_deployment/static/
cp -r /home/ubuntu/flask_project/static/js /home/ubuntu/final_deployment/static/
cp -r /home/ubuntu/flask_project/utils /home/ubuntu/final_deployment/
cp /home/ubuntu/flask_project/app_for_deployment.py /home/ubuntu/final_deployment/app.py
cp /home/ubuntu/flask_project/wsgi.py /home/ubuntu/final_deployment/
cp /home/ubuntu/upload/inputt.pptx /home/ubuntu/final_deployment/static/uploads/

# إنشاء ملف requirements.txt للنشر النهائي
cat > /home/ubuntu/final_deployment/requirements.txt << EOL
Flask==2.3.3
python-pptx==0.6.21
Werkzeug==2.3.7
Flask-Babel==3.1.0
Flask-WTF==1.1.1
WTForms==3.0.1
Pillow==10.0.0
gunicorn==20.1.0
EOL

echo "تم إعداد التطبيق للنشر النهائي!"
