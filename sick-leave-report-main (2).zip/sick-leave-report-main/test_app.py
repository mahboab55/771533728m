import unittest
import os
import tempfile
import shutil
from app import app

class FlaskAppTestCase(unittest.TestCase):
    """اختبارات وحدة لتطبيق Flask"""
    
    def setUp(self):
        """إعداد بيئة الاختبار قبل كل اختبار"""
        app.config['TESTING'] = True
        app.config['WTF_CSRF_ENABLED'] = False
        self.app = app.test_client()
        
        # إنشاء مجلدات مؤقتة للاختبار
        self.test_upload_dir = tempfile.mkdtemp()
        self.test_download_dir = tempfile.mkdtemp()
        app.config['UPLOAD_FOLDER'] = self.test_upload_dir
        app.config['DOWNLOAD_FOLDER'] = self.test_download_dir
    
    def tearDown(self):
        """تنظيف بيئة الاختبار بعد كل اختبار"""
        shutil.rmtree(self.test_upload_dir)
        shutil.rmtree(self.test_download_dir)
    
    def test_index_page(self):
        """اختبار الصفحة الرئيسية"""
        response = self.app.get('/')
        self.assertEqual(response.status_code, 200)
        self.assertIn('تطبيق تقرير الإجازة المرضية', response.data.decode('utf-8'))
    
    def test_form_page(self):
        """اختبار صفحة النموذج"""
        response = self.app.get('/form')
        self.assertEqual(response.status_code, 200)
        self.assertIn('إنشاء تقرير جديد', response.data.decode('utf-8'))
        self.assertIn('البيانات الشخصية', response.data.decode('utf-8'))
    
    def test_code_generator(self):
        """اختبار مولد الرمز العشوائي"""
        from utils.code_generator import generate_random_code
        code = generate_random_code()
        self.assertTrue(code.startswith('PSL'))
        self.assertEqual(len(code), 14)  # PSL + 11 رقم
        self.assertTrue(code[3:].isdigit())

if __name__ == '__main__':
    unittest.main()
