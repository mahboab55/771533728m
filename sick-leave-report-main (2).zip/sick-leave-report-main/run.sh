#!/bin/bash

# هذا النص البرمجي يقوم بتشغيل تطبيق Flask

# التأكد من وجود المجلدات اللازمة
mkdir -p /home/ubuntu/flask_project/static/uploads
mkdir -p /home/ubuntu/flask_project/static/downloads

# نسخ ملف العرض التقديمي الأصلي إلى مجلد التحميل
cp /home/ubuntu/upload/inputt.pptx /home/ubuntu/flask_project/static/uploads/

# تشغيل تطبيق Flask
cd /home/ubuntu/flask_project
export FLASK_APP=app.py
export FLASK_ENV=development
python3 app.py
