// main.js
document.addEventListener('DOMContentLoaded', function() {
    // تحديث اسم الملف المختار عند رفع ملف
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        const fileNameSpan = document.createElement('span');
        fileNameSpan.className = 'file-name';
        input.parentNode.appendChild(fileNameSpan);
        
        input.addEventListener('change', function() {
            if (this.files && this.files.length > 0) {
                fileNameSpan.textContent = this.files[0].name;
            } else {
                fileNameSpan.textContent = '';
            }
        });
    });
    
    // توليد رمز عشوائي عند تحميل الصفحة
    const randomCodeInput = document.getElementById('random_code');
    if (randomCodeInput) {
        randomCodeInput.value = generateRandomCode();
        randomCodeInput.readOnly = true;
    }
    
    // توليد الوقت والتاريخ تلقائيًا
    const timeDateInput = document.getElementById('time_date');
    if (timeDateInput) {
        timeDateInput.value = generateFormattedDateTime();
        timeDateInput.readOnly = true;
    }
    
    // تبديل بين الخطوات في النموذج متعدد الخطوات
    const nextButtons = document.querySelectorAll('.btn-next');
    const prevButtons = document.querySelectorAll('.btn-prev');
    const formSteps = document.querySelectorAll('.form-step');
    const stepIndicators = document.querySelectorAll('.step');
    
    if (nextButtons.length > 0) {
        nextButtons.forEach((button, index) => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // التحقق من صحة الحقول في الخطوة الحالية
                const currentStep = formSteps[index];
                const inputs = currentStep.querySelectorAll('input[required], select[required], textarea[required]');
                let isValid = true;
                
                inputs.forEach(input => {
                    if (!input.value.trim()) {
                        isValid = false;
                        input.classList.add('is-invalid');
                    } else {
                        input.classList.remove('is-invalid');
                    }
                });
                
                if (isValid) {
                    // الانتقال إلى الخطوة التالية
                    formSteps[index].style.display = 'none';
                    formSteps[index + 1].style.display = 'block';
                    
                    // تحديث مؤشرات الخطوات
                    stepIndicators[index].classList.remove('active');
                    stepIndicators[index].classList.add('completed');
                    stepIndicators[index + 1].classList.add('active');
                }
            });
        });
    }
    
    if (prevButtons.length > 0) {
        prevButtons.forEach((button, index) => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                
                // الرجوع إلى الخطوة السابقة
                const currentStepIndex = parseInt(button.getAttribute('data-step')) - 1;
                formSteps[currentStepIndex].style.display = 'none';
                formSteps[currentStepIndex - 1].style.display = 'block';
                
                // تحديث مؤشرات الخطوات
                stepIndicators[currentStepIndex].classList.remove('active');
                stepIndicators[currentStepIndex - 1].classList.remove('completed');
                stepIndicators[currentStepIndex - 1].classList.add('active');
            });
        });
    }
    
    // معاينة الصورة المختارة
    const imageInput = document.getElementById('image');
    const imagePreview = document.getElementById('image-preview');
    
    if (imageInput && imagePreview) {
        imageInput.addEventListener('change', function() {
            if (this.files && this.files[0]) {
                const reader = new FileReader();
                
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreview.style.display = 'block';
                };
                
                reader.readAsDataURL(this.files[0]);
            }
        });
    }
});

// توليد رمز عشوائي بتنسيق PSL + 11 رقم
function generateRandomCode() {
    const prefix = "PSL";
    let numbers = "";
    
    for (let i = 0; i < 11; i++) {
        numbers += Math.floor(Math.random() * 10);
    }
    
    return prefix + numbers;
}

// توليد الوقت والتاريخ بالصيغة المطلوبة: 11:00PM - Sunday, 20 April 2025
function generateFormattedDateTime() {
    const now = new Date();
    
    // الحصول على اليوم
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = days[now.getDay()];
    
    // الحصول على الشهر
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const monthName = months[now.getMonth()];
    
    // الحصول على التاريخ
    const date = now.getDate();
    
    // الحصول على السنة
    const year = now.getFullYear();
    
    // الحصول على الوقت بصيغة 12 ساعة
    let hours = now.getHours();
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // الساعة 0 تصبح 12
    
    // الحصول على الدقائق مع إضافة صفر في البداية إذا كانت أقل من 10
    const minutes = now.getMinutes() < 10 ? '0' + now.getMinutes() : now.getMinutes();
    
    // تنسيق الوقت والتاريخ
    return `${hours}:${minutes}${ampm} - ${dayName}, ${date} ${monthName} ${year}`;
}
