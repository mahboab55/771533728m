import os
import logging
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

# إعداد التسجيل
logger = logging.getLogger(__name__)

def process_pptx(input_path, output_path, placeholders, image_path=None):
    """
    معالجة ملف العرض التقديمي واستبدال النصوص والصور
    
    المعلمات:
        input_path (str): مسار ملف العرض التقديمي المدخل
        output_path (str): مسار ملف العرض التقديمي المخرج
        placeholders (dict): قاموس يحتوي على النصوص المراد استبدالها
        image_path (str, optional): مسار الصورة المراد استبدالها بدل gg_gg
    
    المخرجات:
        bool: True إذا تمت المعالجة بنجاح، False خلاف ذلك
    """
    try:
        # سجلات تصحيح
        logger.debug(f"بدء معالجة ملف العرض التقديمي")
        logger.debug(f"مسار الإدخال: {input_path}")
        logger.debug(f"مسار الإخراج: {output_path}")
        logger.debug(f"مسار الصورة: {image_path}")
        
        # التحقق من وجود ملف الإدخال
        if not os.path.exists(input_path):
            error_msg = f"ملف الإدخال غير موجود: {input_path}"
            logger.error(error_msg)
            raise FileNotFoundError(error_msg)
        
        # التأكد من وجود مجلد الإخراج
        output_dir = os.path.dirname(output_path)
        os.makedirs(output_dir, exist_ok=True)
        
        # التحقق من مسار الصورة إذا تم تحديده
        if image_path and not os.path.exists(image_path):
            logger.warning(f"ملف الصورة غير موجود: {image_path}")
            image_path = None
        
        # استخدام ملف قالب ثابت إذا كان ملف الإدخال غير متاح
        template_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'static','js', 'inputt.pptx')
        if not os.path.exists(input_path) and os.path.exists(template_path):
            logger.info(f"استخدام ملف القالب الثابت: {template_path}")
            input_path = template_path
        
        # تحميل العرض التقديمي
        logger.debug(f"تحميل العرض التقديمي من: {input_path}")
        prs = Presentation(input_path)
        logger.debug(f"تم تحميل العرض التقديمي بنجاح")
        
        # استبدال النصوص والمفتاح gg_gg بصورة
        slide_count = 0
        for slide in prs.slides:
            slide_count += 1
            shape_count = 0
            for shape in slide.shapes:
                shape_count += 1
                if shape.has_text_frame:
                    if "gg_gg" in shape.text and image_path:
                        logger.debug(f"استبدال gg_gg بصورة في الشريحة {slide_count}, الشكل {shape_count}")
                        # حفظ موقع وأبعاد الشكل
                        left = shape.left
                        top = shape.top
                        width = shape.width
                        height = shape.height
                        
                        try:
                            # إزالة الشكل الحالي
                            slide.shapes._spTree.remove(shape._element)
                            
                            # إضافة الصورة بدلاً منه
                            slide.shapes.add_picture(image_path, left, top, width=width, height=height)
                            logger.debug(f"تم استبدال الشكل بالصورة بنجاح")
                        except Exception as e:
                            logger.error(f"خطأ في استبدال الصورة: {str(e)}")
                        continue

                    # استبدال النصوص
                    for paragraph in shape.text_frame.paragraphs:
                        for run in paragraph.runs:
                            original_text = run.text
                            for key, value in placeholders.items():
                                if key in run.text:
                                    run.text = run.text.replace(key, str(value))
                            if original_text != run.text:
                                logger.debug(f"تم استبدال النص '{original_text}' بـ '{run.text}'")
        
        # حفظ العرض الناتج
        logger.debug(f"حفظ العرض الناتج إلى: {output_path}")
        prs.save(output_path)
        logger.debug(f"تم حفظ العرض الناتج بنجاح")
        
        # التحقق من وجود ملف الإخراج
        if os.path.exists(output_path):
            logger.debug(f"ملف الإخراج موجود: {output_path}")
        else:
            logger.error(f"ملف الإخراج غير موجود بعد الحفظ: {output_path}")
        
        return True
    except Exception as e:
        error_msg = f"حدث خطأ أثناء معالجة ملف العرض التقديمي: {str(e)}"
        logger.error(error_msg)
        raise Exception(error_msg)
