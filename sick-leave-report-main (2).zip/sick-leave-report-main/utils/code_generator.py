import random
import string

def generate_random_code():
    """
    توليد رمز عشوائي بتنسيق PSL + 11 رقم
    
    المخرجات:
        str: الرمز العشوائي المولد
    """
    return "PSL" + ''.join(random.choices(string.digits, k=11))
