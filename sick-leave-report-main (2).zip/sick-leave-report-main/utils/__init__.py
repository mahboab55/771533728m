from flask import Flask
from utils.babel_config import configure_babel

def create_app():
    """
    إنشاء وتكوين تطبيق Flask
    
    المخرجات:
        Flask: تطبيق Flask المكون
    """
    app = Flask(__name__)
    
    # تكوين دعم اللغة العربية
    configure_babel(app)
    
    return app
