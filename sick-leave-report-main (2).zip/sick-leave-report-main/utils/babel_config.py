from flask_babel import Babel

def configure_babel(app):
    """
    تكوين دعم اللغة العربية باستخدام Flask-Babel
    
    المعلمات:
        app (Flask): تطبيق Flask
    
    المخرجات:
        Babel: كائن Babel المكون
    """
    babel = Babel(app)
    
    @babel.localeselector
    def get_locale():
        # يمكن تعديل هذه الدالة لاختيار اللغة بناءً على تفضيلات المستخدم
        return 'ar'  # استخدام اللغة العربية افتراضيًا
    
    return babel
