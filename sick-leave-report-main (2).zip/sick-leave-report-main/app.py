import os
import random
import string
from flask import Flask, render_template, request, redirect, url_for, send_from_directory, flash
from werkzeug.utils import secure_filename
from datetime import datetime
import subprocess
import tempfile
import shutil

# إنشاء مجلدات التخزين إذا لم تكن موجودة
UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'uploads')
DOWNLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', 'downloads')
TEMPLATE_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static','js')
ALLOWED_IMAGE_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['DOWNLOAD_FOLDER'] = DOWNLOAD_FOLDER
app.config['TEMPLATE_FOLDER'] = TEMPLATE_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # حد أقصى 16 ميجابايت
app.secret_key = 'seha_sick_leave_report_secret_key'

# التأكد من وجود المجلدات
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)
os.makedirs(TEMPLATE_FOLDER, exist_ok=True)

# التحقق من امتدادات الملفات المسموح بها
def allowed_file(filename, allowed_extensions):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions

# توليد رمز عشوائي بتنسيق PSL + 11 رقم
def generate_random_code():
    return "PSL" + ''.join(random.choices(string.digits, k=11))

# توليد الوقت والتاريخ بالصيغة المطلوبة: 11:00PM - Sunday, 20 April 2025
def generate_formatted_datetime():
    now = datetime.now()
    
    # الحصول على اليوم
    days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
    day_name = days[now.weekday()]
    
    # الحصول على الشهر
    months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']
    month_name = months[now.month - 1]
    
    # الحصول على التاريخ
    date = now.day
    
    # الحصول على السنة
    year = now.year
    
    # الحصول على الوقت بصيغة 12 ساعة
    hours = now.hour
    ampm = 'PM' if hours >= 12 else 'AM'
    hours = hours % 12
    hours = 12 if hours == 0 else hours
    
    # الحصول على الدقائق مع إضافة صفر في البداية إذا كانت أقل من 10
    minutes = f"0{now.minute}" if now.minute < 10 else now.minute
    
    # تنسيق الوقت والتاريخ
    return f"{hours}:{minutes}{ampm} - {day_name}, {date} {month_name} {year}"

# تحويل ملف PPTX إلى PDF
def convert_pptx_to_pdf(pptx_path, pdf_path):
    try:
        # استخدام LibreOffice لتحويل PPTX إلى PDF
        command = ['libreoffice', '--headless', '--convert-to', 'pdf', '--outdir', 
                  os.path.dirname(pdf_path), pptx_path]
        
        # محاولة استخدام LibreOffice
        try:
            subprocess.run(command, check=True, timeout=30)
            return True
        except (subprocess.SubprocessError, FileNotFoundError):
            # إذا فشل LibreOffice، نستخدم طريقة بديلة باستخدام pdf2image و reportlab
            return convert_pptx_to_pdf_alternative(pptx_path, pdf_path)
            
    except Exception as e:
        print(f"Error converting PPTX to PDF: {str(e)}")
        return False

# طريقة بديلة لتحويل PPTX إلى PDF باستخدام pdf2image و reportlab
def convert_pptx_to_pdf_alternative(pptx_path, pdf_path):
    try:
        # استخدام python-pptx لفتح العرض التقديمي
        from pptx import Presentation
        prs = Presentation(pptx_path)
        
        # إنشاء مجلد مؤقت لحفظ الصور
        temp_dir = tempfile.mkdtemp()
        
        # حفظ كل شريحة كصورة
        c = canvas.Canvas(pdf_path, pagesize=letter)
        
        # تحويل كل شريحة إلى صورة وإضافتها إلى ملف PDF
        for i, slide in enumerate(prs.slides):
            # حفظ الشريحة كصورة PNG
            img_path = os.path.join(temp_dir, f"slide_{i}.png")
            
            # إضافة الصورة إلى ملف PDF
            c.drawImage(img_path, 0, 0, width=letter[0], height=letter[1])
            c.showPage()
        
        c.save()
        
        # حذف المجلد المؤقت
        shutil.rmtree(temp_dir)
        
        return True
    except Exception as e:
        print(f"Error in alternative conversion: {str(e)}")
        return False

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/form')
def form():
    return render_template('form.html')

@app.route('/submit', methods=['POST'])
def submit_form():
    if request.method == 'POST':
        # استخدام القالب المدمج مع المشروع
        template_path = os.path.join(app.config['TEMPLATE_FOLDER'], 'inputt.pptx')
        
        # معالجة الصورة إذا تم تحميلها
        image_path = None
        if 'image' in request.files:
            image_file = request.files['image']
            if image_file.filename != '' and allowed_file(image_file.filename, ALLOWED_IMAGE_EXTENSIONS):
                timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
                image_filename = secure_filename(image_file.filename)
                image_filename = f"{timestamp}_{image_filename}"
                image_path = os.path.join('uploads', image_filename)
                image_file.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
        
        # توليد الوقت والتاريخ تلقائيًا إذا لم يتم تقديمه
        time_date = request.form.get('time_date', '')
        if not time_date:
            time_date = generate_formatted_datetime()
        
        # جمع البيانات من النموذج
        form_data = {
            'random_code': request.form.get('random_code', generate_random_code()),
            'name': request.form.get('name', ''),
            'name_en': request.form.get('name_en', ''),
            'id_number': request.form.get('id_number', ''),
            'employer': request.form.get('employer', ''),
            'medical_file_number': request.form.get('medical_file_number', ''),
            'admission_date': request.form.get('admission_date', ''),
            'admission_date_en': request.form.get('admission_date_en', ''),
            'discharge_date': request.form.get('discharge_date', ''),
            'discharge_date_en': request.form.get('discharge_date_en', ''),
            'issue_date': request.form.get('issue_date', ''),
            'time_date': time_date,
            'hospital_name': request.form.get('hospital_name', ''),
            'hospital_name_en': request.form.get('hospital_name_en', ''),
            'physician_name': request.form.get('physician_name', ''),
            'physician_name_en': request.form.get('physician_name_en', ''),
            'physician_title': request.form.get('physician_title', ''),
            'physician_title_en': request.form.get('physician_title_en', ''),
            'license_number': request.form.get('license_number', ''),
            'image_path': image_path
        }
        
        # معالجة ملف العرض التقديمي
        try:
            from utils.pptx_processor import process_pptx
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            output_pptx_filename = f"output_{timestamp}.pptx"
            output_pdf_filename = f"output_{timestamp}.pdf"
            output_pptx_path = os.path.join(app.config['DOWNLOAD_FOLDER'], output_pptx_filename)
            output_pdf_path = os.path.join(app.config['DOWNLOAD_FOLDER'], output_pdf_filename)
            
            # تحويل مسار الصورة إلى المسار الكامل إذا كان موجودًا
            full_image_path = None
            if image_path:
                full_image_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'static', image_path)
            
            # إنشاء قاموس البيانات بالتنسيق المطلوب لمعالجة ملف العرض التقديمي
            placeholders = {
                "الرمز": form_data['random_code'],
                "تاريخ_دخول": form_data['admission_date'],
                "تاريخ_خروج": form_data['discharge_date'],
                "تاريخ_اصدار": form_data['issue_date'],
                "الاسم": form_data['name'],
                "هويهه": form_data['id_number'],
                "جهة_عمل": form_data['employer'],
                "طبيب_معالج": form_data['physician_name'],
                "مسما": form_data['physician_title'],
                "num": form_data['medical_file_number'],
                "dat_in": form_data['admission_date_en'],
                "dat_out": form_data['discharge_date_en'],
                "name_en": form_data['name_en'],
                "name_doc": form_data['physician_name_en'],
                "postii": form_data['physician_title_en'],
                "مستشفى_اسم": form_data['hospital_name'],
                "hospital_name": form_data['hospital_name_en'],
                "ترخيصص": form_data['license_number'],
                "time_date": form_data['time_date']
            }
            
            # معالجة ملف العرض التقديمي
            process_pptx(template_path, output_pptx_path, placeholders, full_image_path)
            
            # تحويل ملف PPTX إلى PDF
            pdf_success = convert_pptx_to_pdf(output_pptx_path, output_pdf_path)
            
            # إرجاع صفحة النتائج
            return render_template('result.html', 
                                  data=form_data, 
                                  output_pptx=output_pptx_filename,
                                  output_pdf=output_pdf_filename if pdf_success else None)
            
        except Exception as e:
            flash(f'حدث خطأ أثناء معالجة الملف: {str(e)}')
            return render_template('result.html', error=str(e))
    
    return redirect(url_for('form'))

@app.route('/download/<filename>')
def download_file(filename):
    return send_from_directory(app.config['DOWNLOAD_FOLDER'], filename, as_attachment=True)

# إضافة مسار للملفات الثابتة للنشر الدائم
@app.route('/static/<path:filename>')
def serve_static(filename):
    return send_from_directory('static', filename)

# إضافة مسار للقوالب للنشر الدائم
@app.route('/templates/<path:filename>')
def serve_template(filename):
    return send_from_directory('templates', filename)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
